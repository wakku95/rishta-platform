<?php

use Illuminate\Foundation\Application;
use Illuminate\Http\Request;

define('LARAVEL_START', microtime(true));

// Determine if the application is in maintenance mode...
if (file_exists($maintenance = __DIR__.'/../rishta-platform/storage/framework/maintenance.php')) {
    require $maintenance;
}

// Register the Composer autoloader...
require __DIR__.'/../rishta-platform/vendor/autoload.php';

// Bootstrap Laravel and handle the request...
/** @var Application $app */
$app = require_once __DIR__.'/../rishta-platform/bootstrap/app.php';

// FIX FOR cPANEL SPLIT DIRECTORY: Tell Laravel that public_html is the public path
$app->usePublicPath(__DIR__);

$app->handleRequest(Request::capture());
